package com.saya.superhero

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

data class Superhero(
    @Parcelize
    val imgSuperhero: Int,
    val nameSuperhero: String,
    val descSuperhero: String

) : Parcelable
